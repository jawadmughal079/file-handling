#include <iostream>
#include <fstream>
using namespace std;
int main()
{
    ifstream read("graded.txt");
    int cases = 0;
    read >> cases;
    for (int i = 0; i < cases; i++)
    {
       
    }

    return 0;
}