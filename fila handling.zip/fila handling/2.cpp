#include <iostream>
#include <fstream>
using namespace std;
int main()
{
    const int size = 5;
    int pointerValue, max = 0, min = 0, same, count = 1, count1 = 0;
    // initlizing variable in f stream library to write data
    fstream writeData("age.txt", ios::out | ios::app);
    // initlizing variable in f stream library to read data
    fstream readData("age.txt", ios::in);
    // initlizing variable for collecting age
    float age;
    // loop for taking age and saving in the file
    // for (int i = 0; i < size; i++)
    // {
    //     cout << "Enter age ;";
    //     cin >> age;
    //     writeData << age<<endl;
    // }
    // loop for reading age and from the file
    readData >> age;
    cout << age << endl;
    pointerValue = age;
    min = age;
    same = age;
    while (readData >> age)
    {
        if (pointerValue < age)
        {
            max = age;
        }
        if (min > age)
        {
            min = age;
        }
        count++;
    }

    cout << "Maximum value is :" << max << endl;
    cout << "Minimum value is :" << min << endl;
    cout << "total number is :" << count;
    cout << "total number is :" << count1;

    writeData.close();
    readData.close();

    return 0;
}