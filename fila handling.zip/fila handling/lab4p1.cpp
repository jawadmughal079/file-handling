#include <iostream>
#include <fstream>
using namespace std;
int main()
{
    ofstream dataStore("sample.txt");
    int numbers;
    cout << "enter a data 1 to 10";
    cout << endl;
    for (int i = 0; i < 10; i++)
    {
        cin >> numbers;
        dataStore << numbers;
    }

    return 0;
}