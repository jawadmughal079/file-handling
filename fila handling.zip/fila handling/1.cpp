#include<iostream>
#include<fstream>
using namespace std;
int main()
{
    const int size =5;
    // initlizing variable in f stream library to write data
    ofstream writeData("age.txt");
    // initlizing variable in f stream library to read data
    ifstream readData("age.txt");
    // initlizing variable for collecting age
    float age;
    // loop for taking age and saving in the file
    for (int i = 0; i < size; i++)
    {
        cout << "Enter age ;";
        cin >> age;
        writeData << age<<endl;
    }
    // loop for reading age and from the file
      while (readData>>age)
    {
        cout<<age<<"  ";
    }


    writeData << "Hello world";

    writeData.close();
    readData.close();

	return 0;
}